import pygame
import os
from pathlib import Path

class AudiobookPlayer:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 200))
        pygame.display.set_caption("Audiobook Player")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.playing = False
        self.current_track = 0
        self.tracks = self.load_audiobooks()

    def load_audiobooks(self):
        # Replace these paths with the paths to your audiobook files
        audiobook_folder = Path("path/to/your/audiobooks")
        tracks = [str(file) for file in audiobook_folder.glob("*.mp3")]
        return tracks

    def play(self):
        pygame.mixer.music.load(self.tracks[self.current_track])
        pygame.mixer.music.play()

    def pause(self):
        pygame.mixer.music.pause()

    def resume(self):
        pygame.mixer.music.unpause()

    def next_track(self):
        self.current_track = (self.current_track + 1) % len(self.tracks)
        self.play()

    def prev_track(self):
        self.current_track = (self.current_track - 1) % len(self.tracks)
        self.play()

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        if self.playing:
                            self.pause()
                        else:
                            self.resume()
                        self.playing = not self.playing
                    elif event.key == pygame.K_n:
                        self.next_track()
                    elif event.key == pygame.K_p:
                        self.prev_track()

            self.screen.fill((255, 255, 255))
            text = self.font.render("Press Space to Play/Pause, N for Next Track, P for Previous Track", True, (0, 0, 0))
            self.screen.blit(text, (10, 150))
            pygame.display.flip()
            self.clock.tick(30)

        pygame.quit()

if __name__ == "__main__":
    player = AudiobookPlayer()
    player.run()
